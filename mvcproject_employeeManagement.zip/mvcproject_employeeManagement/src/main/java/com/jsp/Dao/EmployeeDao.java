package com.jsp.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.Dto.Employee;

@Repository
public class EmployeeDao {

	@Autowired
	EntityManager manager;
	
	@Autowired
	EntityTransaction transaction;
	
	//to insert employee object into db
	public void saveEmployee(Employee employee) {
		transaction.begin();
		manager.persist(employee);
		transaction.commit();
	}
	
	//to find an employee
	public Employee findEmployeeById(int id) {
		Employee emp=manager.find(Employee.class,id);
		return emp;
	}
	
	//to delete an employee
	public int deleteEmployee(int id) {
		Employee emp=manager.find(Employee.class,id);
		
		if(emp!=null) {
			transaction.begin();
			manager.remove(emp);
			transaction.commit();
			return 1;
		}
		else {
			return 0;
		}
	}
	
	//to update employee object
	public boolean updateEmployee(int id,String newName,long newPhone) {
		Employee emp=manager.find(Employee.class,id);
			
		if(emp!=null) {
		emp.setName(newName);
		emp.setPhone(newPhone);
		transaction.begin();
		manager.merge(emp);
		transaction.commit();
		
		return true;
		}
		else {
			return false;
		}
		
	}
	
	
	//to retrieve all employee details
	public List<Employee> getAllEmployees(){
		Query q=manager.createQuery("select e from Employee e");
		List<Employee> list=q.getResultList();
		return list;
	}
	
}
