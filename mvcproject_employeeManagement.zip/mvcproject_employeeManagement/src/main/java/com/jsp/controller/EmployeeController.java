package com.jsp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.Dao.EmployeeDao;
import com.jsp.Dto.Employee;

@Controller
public class EmployeeController {

	@Autowired
	EmployeeDao dao;
	
	@RequestMapping("/emp")
	public ModelAndView saveEmployee() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("employee",new Employee());
		mv.setViewName("create.jsp");
		return mv;
	}
	
	@RequestMapping("/save")
	@ResponseBody
	public String addEmployee(@ModelAttribute Employee employee) {
		dao.saveEmployee(employee);
		return "EMPLOYEE DETAILS ADDED SUCCESSFULLY...";
	}
	
	
	@RequestMapping("/search")
	public ModelAndView searchEmployee() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("employee",new Employee());
		mv.setViewName("get.jsp");
		return mv;
	}
	
	@RequestMapping("/view")
	public ModelAndView findEmployee(@ModelAttribute Employee employee) {
		int id=employee.getId();
		Employee emp=dao.findEmployeeById(id);
		ModelAndView mv= new ModelAndView();
		mv.addObject("employee",emp);
		mv.setViewName("display.jsp");
		return mv;
	}
	
	@RequestMapping("/delete")
	public ModelAndView deleteEmployee() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("employee",new Employee());
		mv.setViewName("delete.jsp");
		return mv;
	}
	
	@RequestMapping("/remove")
	@ResponseBody
	public String removeEmployee(@ModelAttribute Employee employee) {
		
		int n=dao.deleteEmployee(employee.getId());
		if(n==1) {
			return "EMPLOYEE DETAILS REMOVED SUCCESSFULLY...!";
		}
		else {
			return "EMPLOYEE ID NOT FOUND,ENTER VALID EMPLOYEE ID..!";
		}
	}
	
	@RequestMapping("/update")
	public ModelAndView updateEmployee() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("employee",new Employee());
		mv.setViewName("update.jsp");
		return mv;
	}
	
	@RequestMapping("/edit")
	@ResponseBody
	public String editEmployee(@ModelAttribute Employee emp) {
		boolean value=dao.updateEmployee(emp.getId(), emp.getName(), emp.getPhone());
		if(value==true) {
			return "EMPLOYEE DETAILS UPDATED SUCCESSFULLY..!";
		}
		else {
			return  "EMPLOYEE ID IS INVALID";
		}
	}
	
	
	@RequestMapping("/display")
	public ModelAndView displayAllEmployees() {
		
		List<Employee> list=dao.getAllEmployees();
		ModelAndView mv=new ModelAndView();
		mv.addObject("employeeList",list);
		mv.setViewName("displayAll.jsp");
		return mv;
		
	}
}
